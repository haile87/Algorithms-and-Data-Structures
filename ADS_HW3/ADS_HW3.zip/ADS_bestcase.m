y = 8;
fplot(y)